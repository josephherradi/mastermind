Lancement du jeu:
-en dev mode: 
utiliser le lanceur dev.bat sous windows ou la commande suivante:
java -jar Mastermind.jar dev
- en mode normal:
utiliser le lanceur mastermind.bat sous windows ou la commande suivante:
java -jar Mastermind.jar